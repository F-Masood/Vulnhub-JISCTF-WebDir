<?php
session_start();
if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true)
{
}
else
{
	header("Location: login.php");
}
?>

<?php
   if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      if($file_size > 2097152)
{
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true)
{
         move_uploaded_file($file_tmp,"uploaded_files/".$file_name);
	 chmod("/var/www/html/uploaded_files/".$file_name, 0777);
         echo "Success !!! File uploaded to uplodaded_files directory";
      
}
else
{
         print_r($errors);
     
 }
   }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Upload Center</title>
        
        <!-- Our CSS stylesheet file -->
        <link rel="stylesheet" href="assets/css/styles.css" />
        
        <!--[if lt IE 9]>
          <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
    </head>
    
    <body>
		
		<header>
			<h1>Media Upload Center</h1>
			<center> <h2> Welcome to Media Upload Center</h2> </center>
			<h5> Note: We only allow image files to be uploaded to our site</h5>
			
		</header>
		
		<div id="dropbox">
			<br />
			<br />
			<center>
				<form name= "form" action="" method="POST" enctype="multipart/form-data">
        	 		<input type="file"  name= "image" id="image"  accept="image/*" onChange="validate(this.value)"/>
			        <input type="submit"  value="Upload File" />
		        	</form>
			</center>
		</div>
		
        <footer>
	        <h2>Jordan Infosec CTF - 2017</h2>
            <a class="tzine" href="http://www.technawi.net">Powered by : Technawi[dot]net</a>
        </footer>
       
        <!-- Including The jQuery Library -->
		<script src="http://code.jquery.com/jquery-1.6.3.min.js"></script>
		
		<!-- Including the HTML5 Uploader plugin -->
		<script src="assets/js/jquery.filedrop.js"></script>
		
		<!-- The main script file -->
        <script src="assets/js/script.js"></script>

<script>
function validate(file) 
{
    var ext = file.split(".");
    ext = ext[ext.length-1].toLowerCase();      
    var arrayExtensions = ["jpg" , "jpeg", "png", "bmp", "gif"];

    if (arrayExtensions.lastIndexOf(ext) == -1) {
        alert("Wrong extension type.");
        $("#image").val("");
    }
}

</script> 

    </body>
</html>

