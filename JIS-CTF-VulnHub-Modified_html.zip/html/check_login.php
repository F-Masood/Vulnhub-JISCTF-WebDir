<?php
session_start();
$username = $_POST["user_name"];
$password = $_POST["pass_word"];
if($username ==="admin" && $password==="3v1l_H@ck3r")
{
	$_SESSION['loggedin']=true;
	header("Location: index.php");	
}
else
{
	echo "<br/><h1 style='color:red'><center>Error in username/password</center></h1>";
}
?>
